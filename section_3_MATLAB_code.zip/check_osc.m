function check_osc(V, EPSILON)

    m = size(V,2);

    M = V'*V;

    if max(max(abs(M-eye(m))))>EPSILON
        fprintf('Error: matrix columns do not form an orthonormal set\n');
    end
