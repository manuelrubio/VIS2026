%%%%%%% Closest "scaled" orthogonal matrix with fixed axis vector %%%%%%%%% 
% Section 3.3.2
% Related equations: (21)
function Vorth = closest_SPSC_matrix_fixed_vector(V, fixed_vector_index)
% V: matrix of axis vectors. Columns of V must be orthogonal to each other
% and have the same length
% fixed_vector_index: index of the fixed (row) axis vector in V

    [n,m] = size(V);

    % Swap vectors 1 <-> i(selected)
    aux_vec = V(1,:);
    V(1,:) = V(fixed_vector_index,:);
    V(fixed_vector_index,:) = aux_vec;

    w = V(1,:)';
    Vp = V(2:n,:);

    [best_c_Brents_method, ~] = local_min(0.001, 1000, 4*eps, 10^(-5), V, w);
    S = eye(m) - w*w'/best_c_Brents_method;
    H = S^(1/2);
    M = Vp*H;
    [Um, ~, Wm] = svd(M,0);
    Vorth = [w'; sqrt(best_c_Brents_method)*Um*Wm'*H];

    % Undo swap
    aux_vec = Vorth(1,:);
    Vorth(1,:) = Vorth(fixed_vector_index,:);
    Vorth(fixed_vector_index,:) = aux_vec;  
end
