% Function g(c) in Section 3.3.2
function z = obj_spsc(c, V, w)
    m = size(V,2);

    S = eye(m) - w*w'/c;
    e = eig(S);
    if sum(all(e>=0))==1
        
        [~, Sigma, ~] = svd(V(2:end,:)*S^(1/2),0);
        g = trace(Sigma);

        z = m*c - 2*(w'*V(1,:)' + sqrt(c)*g);
    else
        z = Inf;
    end
end
