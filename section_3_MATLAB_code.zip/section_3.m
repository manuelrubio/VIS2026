clear;
clc;

rng(1); % initialize random seed



N = 1000;  % Number of observations
n = 5;     % number of variables
m = 2;     % dimension of visualization space

V = randn(n,m);  % Axis vector
X = randn(N,n);  % Data matrix


%%%%%%%%%%%%%%%%%%% Methods presented in section 3 %%%%%%%%%%%%%%%%%%%%
V_OSC = closest_OSC_matrix(V);
check_osc(V_OSC, 10^(-10));

V_OSC_data = optimal_point_preservation(V, X);
check_osc(V_OSC_data, 10^(-10));

V_SPSC = closest_SPSC_matrix(V);
check_spsc(V_SPSC, 10^(-10));

selected_variable = ceil(rand()*n);
V_OSC_fixed = closest_OSC_matrix_fixed_vector(V_OSC, selected_variable);
check_osc(V_OSC_fixed, 10^(-10));

selected_variable = ceil(rand()*n);
V_SPSC_fixed = closest_SPSC_matrix_fixed_vector(V_SPSC, selected_variable);
check_spsc(V_SPSC_fixed, 10^(-10));

% Alternative energy minimization method. Converges to V_OSC
mu = 0.001;        
EPSILON = 10^(-10);
V_OSC_energy_alt = energy_minimization_alt(V, mu, EPSILON);
check_osc(V_OSC_energy_alt, 10^(-4));


%%%%%%%%%%%%%%%%%%% Methods in literature %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mu = 0.001;        
EPSILON = 10^(-10);
V_OSC_energy = energy_minimization(V, mu, EPSILON);
check_osc(V_OSC_energy, 10^(-4));


selected_variable = ceil(rand()*n);
V_SPSC_bls = spsc_best_length_scaling(V_SPSC, selected_variable);  % With correction not mentioned in paper
check_spsc(V_SPSC_bls, 10^(-10));

V_SPSC_ld = spsc_least_distortion(V_SPSC, selected_variable);  % With correction not mentioned in paper
check_spsc(V_SPSC_ld, 10^(-10));




