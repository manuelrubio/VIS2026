%%%%%%%%%%%%%%%% Optimal preservation of projected points %%%%%%%%%%%%%%%%%
% Section 3.1
% Related equations: (14)
function Vorth = optimal_point_preservation(V, X)
% V: matrix of axis vectors
% X: data matrix

    [U,~,W] = svd(X'*(X*V),0);  % Singular value decomposition

    Vorth = U*W';
end
