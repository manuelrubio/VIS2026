%%%%%%%%%%%%% Closest orthogonal matrix with fixed axis vector %%%%%%%%%%%% 
% Section 3.3.1
% Related equations: (17) and (20)
function Vorth = closest_OSC_matrix_fixed_vector(V, fixed_vector_index)
% V: matrix of axis vectors. Columns of V must be orthogonal to each other
% and have unit length
% fixed_vector_index: index of the fixed (row) axis vector in V

    [n,m] = size(V);

    % Swap vectors 1 <-> i(selected)
    aux_vec = V(1,:);
    V(1,:) = V(fixed_vector_index,:);
    V(fixed_vector_index,:) = aux_vec;
    
    w = V(1,:)';
    Vp = V(2:n,:);

    M = eye(m) - w*w';
    H = M^(1/2);
    [Q, ~, R] = svd(Vp*H,0);
    Vorth = [w'; Q*R'*H];    
    
    % Undo swap
    aux_vec = Vorth(1,:);
    Vorth(1,:) = Vorth(fixed_vector_index,:);
    Vorth(fixed_vector_index,:) = aux_vec;  
end
