%%%%%%%%%%%%%%%%%%%%% Closest orthogonal matrix %%%%%%%%%%%%%%%%%%%%%%%%%%%
% Section 3.1
% Related equations: (12) and (13)
function Vorth = closest_OSC_matrix(V)
% V: matrix of axis vectors

    [U,~,W] = svd(V,0); % Singular value decomposition

    Vorth = U*W';
end
