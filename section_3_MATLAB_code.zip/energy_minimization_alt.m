% Variant of energy minimization algorithm in [24] Lehmann & Theisel
function Venergy = energy_minimization_alt(V, mu, EPSILON)
% V: matrix of axis vectors
% mu: step size of gradient descent algorithm
% EPSILON: small constant for gradient descent stopping criterion

    n = size(V,1);

    energy  = (norm(V(:,1))^2-1)^2 + (norm(V(:,2))^2-1)^2 + 2*(V(:,1)'*V(:,2))^2;
    Venergy = V;
    Delta = zeros(n,2);
    while energy>EPSILON  
        xy = Venergy(:,1)'*Venergy(:,2);
        xx = Venergy(:,1)'*Venergy(:,1);
        yy = Venergy(:,2)'*Venergy(:,2);

        Delta(:,1) = 4*(xx-1)*Venergy(:,1) + 4*xy*Venergy(:,2);
        Delta(:,2) = 4*(yy-1)*Venergy(:,2) + 4*xy*Venergy(:,1);

        Venergy = Venergy - mu*Delta;
        energy = (Venergy(:,1)'*Venergy(:,1)-1)^2 + (Venergy(:,2)'*Venergy(:,2)-1)^2 + 2*(Venergy(:,1)'*Venergy(:,2))^2;
    end       
end
