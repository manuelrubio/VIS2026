function check_spsc(V, EPSILON)

    m = size(V,2);

    c = norm(V(:,1))^2;
    M = V'*V;

    if max(max(abs(M-c*eye(m))))>EPSILON
        fprintf('Error: matrix columns are not orthogonal or do not have the same length\n');
    end
