%%%%%%%%%%%%%%%%%%%% Closest scaled "orthogonal" matrix %%%%%%%%%%%%%%%%%%% 
% Section 3.2
% Related equations: (15) and (16)
function Vorth = closest_SPSC_matrix(V)
% V: matrix of axis vectors

    [U,S,W] = svd(V,0);
    sqrt_c = trace(S)/2;    % optimal scaling
    Vorth = sqrt_c*U*W';
end
