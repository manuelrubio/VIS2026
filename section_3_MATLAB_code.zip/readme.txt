The MATLAB (.m) files in this folder are related to Section 3 of the paper.

Functions of algorithms/methods proposed in the paper:
- closest_OSC_matrix(). Section 3.1. Equations (12) and (13)
- optimal_point_preservation(). Section 3.1. Equation (14)
- closest_SPSC_matrix(). Section 3.2. Equations (15) and (16)
- closest_OSC_matrix_fixed_vector(). Section 3.3.1. Equations (17) and (20)
- closest_SPSC_matrix_fixed_vector(). Section 3.3.2. Equations (21). Auxiliary functions:
  - obj_spsc(). Function g(c)
  - local_min(). Brent's method (Adapted code MATLAB version by John Burkardt)

  Extra:
  - energy_minimization_alt(). Section 3.1. % Variant of energy minimization algorithm in [24] Lehmann & Theisel


Functions of algorithms/methods proposed in the literature:
- energy_minimization(). Section 3.1. Energy minimization algorithm in [24] Lehmann & Theisel
- spsc_best_length_scaling(). SPSC method in [30], Eq. 9. Best length scaling
- spsc_least_distortion(). SPSC method in [30], Eq. 9. Least distortion of star coordinates


Auxiliary functions for checking orthogonal matrices:
- check_osc(). Prints error message if matrix columns do not form an orthonormal set
- check_spsc(). Prints error message if matrix columns are not orthogonal or do not have the same length


Example file:
- section_3.m

