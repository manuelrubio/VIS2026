% SPSC method in [30], Eq. 9. Best length scaling
function Vorth = spsc_best_length_scaling(V, fixed_vector_index)
% V: matrix of axis vectors. Columns of V must be orthogonal to each other
% and have the same length
% fixed_vector_index: index of the fixed (row) axis vector in V

n = size(V,1);

i = fixed_vector_index;

values = zeros(1,n);
values(i) = Inf;

x = V(i,1);
y = V(i,2);

Vorth = V;

w = [x,y]';
for k = 1:n
    if k~=i
        Vnew = Vorth;
        Vnew(i,:) = w';

        C1 = Vorth(i,1)*Vorth(i,2) - w(1)*w(2) + Vorth(k,1)*Vorth(k,2);
        C2 = (Vorth(i,1)^2 - Vorth(i,2)^2) - (w(1)^2 - w(2)^2) + (Vorth(k,1)^2 - Vorth(k,2)^2);
    
        x = sqrt((C2 + sqrt( C2^2 + 4*C1^2 ))/2);
        y = sqrt((-C2 + sqrt( C2^2 + 4*C1^2 ))/2);

        if abs(-x-Vorth(k,1))<abs(x-Vorth(k,1))
            x = -x;
        end
        if abs(-y-Vorth(k,2))<abs(y-Vorth(k,2))
            y = -y;
        end

        Vnew(k,:) = [x,y];

        %%%%%%%% Correction added by Manuel Rubio-Sánchez %%%%%%%%%%%%
        %%%%%%%% Make sure Vnew matrix has orthogonal columns %%%%%%%%
        check_orth = Vnew'*Vnew;
        if abs(check_orth(1,2))>10^(-6)
            if norm([-x,y] - Vorth(k,:))<norm([x,-y] - Vorth(k,:))
                Vnew(k,:) = [-x,y];
            else
                Vnew(k,:) = [x,-y];
            end
        end

        values(k) = norm(Vnew(:,1),2)^2 - 1;  % Want this value to be closest to 0
    end
end

[~, best_index] = min(abs(values));

Vnew = Vorth;
Vnew(i,:) = w';

C1 = Vorth(i,1)*Vorth(i,2) - w(1)*w(2) + Vorth(best_index,1)*Vorth(best_index,2);
C2 = (Vorth(i,1)^2 - Vorth(i,2)^2) - (w(1)^2 - w(2)^2) + (Vorth(best_index,1)^2 - Vorth(best_index,2)^2);                  

x = sqrt((C2 + sqrt( C2^2 + 4*C1^2 ))/2);
y = sqrt((-C2 + sqrt( C2^2 + 4*C1^2 ))/2);

if abs(-x-Vorth(best_index,1))<abs(x-Vorth(best_index,1))
    x = -x;
end
if abs(-y-Vorth(best_index,2))<abs(y-Vorth(best_index,2))
    y = -y;
end

Vnew(best_index,:) = [x,y];   

%%%%%%%% Correction added by Manuel Rubio-Sánchez %%%%%%%%%%%%
%%%%%%%% Make sure Vnew matrix has orthogonal columns %%%%%%%%
check_orth = Vnew'*Vnew;
if abs(check_orth(1,2))>10^(-6)
    if norm([-x,y] - Vorth(best_index,:))<norm([x,-y] - Vorth(best_index,:))
        Vnew(best_index,:) = [-x,y];
    else
        Vnew(best_index,:) = [x,-y];
    end
end

Vorth = Vnew;
